const $sizeGroup = $("[data-size-group]");
const $productSize = $("#product-size");

const $secondaryImages = $("[data-secondary-images]");
const $primaryImage = $("[data-primary-image]");

$sizeGroup.on("click", "button", function () {
    $sizeGroup.find(".active").removeClass("active");
    $(this).addClass("active");

    $productSize.val($(this).text());
});

$secondaryImages.on("click", "button", function () {
    const $oldImage = $primaryImage.attr("src");
    const $newImage = $(this).find("img").attr("src");

    const animationTimer = 100;

    $primaryImage.fadeOut(animationTimer, function () {
        $primaryImage.attr("src", $newImage);
        $primaryImage.fadeIn(animationTimer);
    });

    $(this).find("img").fadeOut(animationTimer, function () {
        $(this).attr("src", $oldImage);
        $(this).fadeIn(animationTimer);
    });
});