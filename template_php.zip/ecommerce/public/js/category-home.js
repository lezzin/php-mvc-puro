const $orderDropdown = $("#order-product-filter");
const $selectedOrder = $("[data-order]");

$orderDropdown.on("click", ".dropdown-menu button", function() {
    $orderDropdown.find(".active").removeClass("active");
    $(this).addClass("active");
    $selectedOrder.text(String($(this).text()));
});