const $table = $("#products-table");
const $tbody = $table.find("tbody");

async function populateProductsTable() {
    try {
        const products = await getProducts();
        $tbody.empty();

        if (products.length < 1) {
            $tbody.append($("<tr>").append($("<td>").addClass("text-center").attr("colspan", 5).text("Nenhum produto cadastrado")));
            return;
        }

        products.forEach(product => {
            const formattedPrice = new Intl.NumberFormat("pt-BR", {
                style: "currency",
                currency: "BRL"
            }).format(product.price);

            const $tr = $("<tr>").append(
                $("<td>").text(product.product_id),
                $("<td>").text(product.name),
                $("<td>").text(formattedPrice),
                $("<td>").text(product.description),
                $("<td>").html(`
                    <div class="btn-group">
                        <button data-bs-toggle="modal" data-bs-target="#product-${product.product_id}-modal" type="button" class="btn btn-sm btn-primary"><i class="bi bi-eye"></i></button>
                        <button type="button" class="btn btn-sm btn-danger" data-delete-product-id="${product.product_id}"><i class="bi bi-trash"></i></button>
                    </div>

                    <div class="modal fade" id="product-${product.product_id}-modal" tabindex="-1" aria-labelledby="product-${product.product_id}-modal-label" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="product-${product.product_id}-modal-label">${product.name}</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    ${product.primaryImage ? `<img src="${$url}/upload/${product.primaryImage.url}" class="img-fluid mb-3 rounded" alt="${product.name}">` : ""}

                                    ${(product.secondaryImages.length > 0) ?
                        `<div class="d-flex gap-1 flex-wrap mb-3">
                                        ${product.secondaryImages.map(image => `<div class="ratio ratio-1x1 p-2 bg-light" style="max-width: 72px"><img src="${$url}/upload/${image.url}" class="rounded object-fit-cover img-fluid" alt="${product.name}"></div>`).join("")}
                                    </div>` :
                        ""}

                                    <form class="needs-validation" novalidate method="post" action="${$url}product/actions/save" data-edit-form enctype="multipart/form-data">
                                        <input type="hidden" name="id" value="${product.product_id}">
                                        <input type="hidden" name="category" value="${product.category_id}">

                                        <div class="form-group mb-3">
                                            <label for="edit-product-name-${product.product_id}">Nome</label>
                                            <input type="text" name="name" id="edit-product-name-${product.product_id}" class="form-control" placeholder="Camisa masculina básica" required value="${product.name}">
                                            <div class="invalid-feedback">
                                                Insira o nome do produto!
                                            </div>
                                        </div>

                                        <div class="form-group mb-3">
                                            <label for="edit-product-price-${product.product_id}">Preço</label>
                                            <input type="text" name="price" id="edit-product-price-${product.product_id}" class="form-control" placeholder="R$0,00" required value="${product.price}">
                                            <div class="invalid-feedback">
                                                Insira o preço do produto!
                                            </div>
                                        </div>

                                        <div class="form-group mb-3">
                                            <label for="edit-product-description-${product.product_id}">Descrição</label>
                                            <textarea name="description" id="edit-product-description-${product.product_id}" class="form-control" placeholder="Camisa masculina de algodão e gola alta" rows="3">${product.description}</textarea>
                                            <div class="invalid-feedback">
                                                Insira a descrição do produto!
                                            </div>
                                        </div>

                                        <button class="btn btn-primary" type="submit">Concluir edição</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                `)
            );

            $tbody.append($tr);
        });

        $table.on("click", "[data-delete-product-id]", function () {
            const productId = $(this).data("delete-product-id");
            $table.find(`[data-delete-product-id="${productId}"]`).closest("tr").remove();
            deleteProduct(productId);
        });

        $("[data-edit-form]").each(function (_, form) {
            $(form).submit(function (e) {
                e.preventDefault();

                const $form = $(this);
                const formData = new FormData($form[0]);
                const action = $form.attr("action");

                $.ajax({
                    url: action,
                    type: "POST",
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function (data) {
                        showMessage(data.message);
                        populateProductsTable();
                    },
                    error: function (_xhr, _status, error) {
                        showMessage("An error occurred: " + error);
                    },
                    complete: function () {
                        $("body").removeClass("modal-open");
                        $(".modal-backdrop").remove();
                    }
                });
            });
        });

        populateCategoriesSelect();
    } catch (error) {
        showMessage("Ocorreu um erro ao buscar os produtos");
    }
}

function deleteProduct(productId) {
    $.ajax({
        url: `${$url}/product/actions/delete/${productId}`,
        method: "DELETE",
    })
        .done(function (data) {
            showMessage(data.message);
        })
        .fail(function (_xhr, _status, error) {
            showMessage("An error occurred: " + error);
        })
        .always(function () {
            populateProductsTable();
        });
}

async function populateCategoriesSelect() {
    const categories = await getCategories();
    const productCategory = $("[data-product-category]");
    productCategory.empty();

    categories.forEach(element => {
        productCategory.append(`<option value="${element.category_id}">${element.name}</option>`);
    });
}

$("#product-form").submit(function (e) {
    e.preventDefault();

    const $form = $(this);
    const formData = new FormData($form[0]);
    const action = $form.attr("action");

    $.ajax({
        url: action,
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function (data) {
            showMessage(data.message);
            $form.trigger("reset");
            $form.removeClass("was-validated");

            populateProductsTable();
        },
        error: function (_xhr, _status, error) {
            showMessage("An error occurred: " + error);
        },
         always: function () {
            $form.removeClass("was-validated");
        },

    });
});

$("#product-image-quantity").on("change", function () {
    const $fileInputQuantity = $(this).val();
    const productImagesContainer = $("#product-images-container");
    productImagesContainer.empty();

    for (let index = 1; index <= $fileInputQuantity; index++) {
        const formGroupClass = index >= $fileInputQuantity ? "mb-1" : "mb-2";
        productImagesContainer.append(
            `<div class="form-group ${formGroupClass}">
                <label for="product-image-${index}">Imagem ${index}</label>
                <input type="file" name="image[]" id="product-image-${index}" class="form-control" required>
                <div class="invalid-feedback">
                    Insira a imagem ${index}!
                </div>
            </div>`
        );
    }
});

populateCategoriesSelect();
populateProductsTable();