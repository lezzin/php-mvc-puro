const $table = $("#categories-table");
const $tbody = $table.find("tbody");
const $modalEditCategory = $("#modal-edit-category");

async function populateCategoriesTable() {
    try {
        const categories = await getCategories();
        $tbody.empty();

        if (categories.length < 1) {
            $tbody.append($("<tr>").append($("<td>").addClass("text-center").attr("colspan", 3).text("Nenhuma categoria cadastrada")));
            return;
        }

        categories.forEach((category) => {
            const $tr = $("<tr>");
            $tr.append($("<td data-name>").html(`
                <div class="d-flex align-items-center gap-2">
                    <img src="${$url}/upload/${category.image}" alt="${category.name}" class="img-thumbnail" style="max-width: 32px;">
                    <span class="m-0">${category.name}</span>
                `));
            $tr.append($("<td>").html(`
            <div class="btn-group">
                <button type="button" class="btn btn-sm btn-success" data-edit-category-id="${category.category_id}"><i class="bi bi-pen"></i></a>
                <button type="button" class="btn btn-sm btn-danger" data-delete-category-id="${category.category_id}"><i class="bi bi-trash"></i></a>
            </div>
        `));
            $tbody.append($tr);
        });

        $table.on("click", "[data-delete-category-id]", function () {
            const categoryId = $(this).data("delete-category-id");
            $table.find(`[data-delete-category-id="${categoryId}"]`).closest("tr").remove();
            deleteCategory(categoryId);
        });

        $table.on("click", "[data-edit-category-id]", function () {
            const categoryId = $(this).data("edit-category-id");

            $("#modal-edit-category").modal("show");
            $("#edit-category-id").val(categoryId);
            $("#edit-category-name").val($table.find(`[data-edit-category-id="${categoryId}"]`).closest("tr").find("[data-name] span").text());
        });
    } catch (error) {
        showMessage("Ocorreu um erro ao buscar as categorias");
    }
}

$("#category-edit-form").submit(function (e) {
    e.preventDefault();

    const $form = $(this);
    const formData = $form.serialize();
    const action = $form.attr("action");

    $.post(action, formData)
        .done(function (data) {
            showMessage(data.message);
            $table.find(`[data-edit-category-id="${$form.find("#edit-category-id").val()}"]`).closest("tr").find("[data-name] span").text($form.find("#edit-category-name").val());
            $modalEditCategory.modal("hide");

            $form.trigger("reset");
            $form.removeClass("was-validated");
        })
        .fail(function (_xhr, _status, error) {
            showMessage("An error occurred: " + error);
        })
});

function deleteCategory(categoryId) {
    $.ajax({
        url: `${$url}category/actions/delete/${categoryId}`,
        method: "DELETE",
    })
        .done(function (data) {
            showMessage(data.message);
        })
        .fail(function (_xhr, _status, error) {
            showMessage("An error occurred: " + error);
        })
        .always(function () {
            getCategories();
        });
}

$("#category-form").submit(function (e) {
    e.preventDefault();

    const $form = $(this);
    const formData = new FormData($form[0]);
    const action = $form.attr("action");

    $.ajax({
        url: action,
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function (data) {
            showMessage(data.message);
            $form.removeClass("was-validated");
            $form.trigger("reset");
            
            populateCategoriesTable();
        },
        error: function (_xhr, _status, error) {
            showMessage("An error occurred: " + error);
        },
    });
});

populateCategoriesTable();