const $url = $("body").attr("data-url");

function showMessage(message) {
    const $toastContainer = $("#toast-container");

    const $toast = `
        <div class="toast" role="alert" aria-live="assertive" aria-atomic="true"> 
            <div class="toast-header">
                <strong class="me-auto">Ecommerce</strong>
                <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
            <div class="toast-body">${message}</div>
        </div>`;

    $toastContainer.append($toast);
    const toast = new bootstrap.Toast($toastContainer.find(".toast:last"));
    toast.show();
}

async function getCategories() {
    let categories = [];

    try {
        const data = await $.get(`${$url}/category/actions/get`);
        categories = data;
    } catch (error) {
        showMessage("An error occurred: " + error);
    }

    return categories;
}

async function getProducts() {
    let products = [];

    try {
        const data = await $.get(`${$url}/product/actions/get`);
        products = data;
    } catch (error) {
        showMessage("An error occurred: " + error);
    }

    return products;
}