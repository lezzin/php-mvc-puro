<div class="container-fluid px-5 mb-5">
    <section>
        <h2 class="mt-2 mb-3">Categorias</h2>
        <div class="d-flex justify-content-center align-items-center flex-wrap gap-2">
            <?php foreach ($categories as $category) : ?>
                <a class="p-2 text-decoration-none" href="<?= base_url("category/" . strtolower($category->name)) ?>" style="max-width: 200px">
                    <div class="ratio ratio-1x1">
                        <img src="<?= base_url("upload/{$category->image}") ?>" alt="<?= $category->name ?>" class="object-fit-cover img-fluid rounded-circle">
                    </div>

                    <p class="link-primary m-0 fw-100 mt-3"><?= $category->name ?></p>
                </a>
            <?php endforeach ?>
        </div>
    </section>

    <section>
        <div class="d-flex align-items-start flex-wrap gap-2">
            <?php foreach ($products as $product) : ?>
                <a class="card card-body p-2 text-decoration-none" href="<?= base_url("category/" . strtolower($product->category) . "/{$product->product_id}") ?>" style="max-width: 230px">
                    <div class="ratio ratio-1x1">
                        <img src="<?= base_url("upload/{$product->image}") ?>" alt="" class="object-fit-cover img-fluid rounded">
                    </div>

                    <p class="link-primary m-0 fw-100 mt-3"><?= $product->name ?></p>
                    <p class="link-primary m-0 fw-bold fs-5"><?= format_currency($product->price) ?></p>
                </a>
            <?php endforeach ?>
        </div>
    </section>
</div>
</body>

</html>