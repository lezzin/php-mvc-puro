    <div class="container-fluid px-5 mb-5">
        <div class="card">
            <div class="border-bottom p-3">
                <div>
                    <h2><?= ucfirst($category->name) ?></h2>
                </div>

                <div class="d-flex justify-content-between align-items-center mt-1">
                    <span>Exibindo 1 resultado de 10</span>

                    <div class="dropdown-center" id="order-product-filter">
                        <button class="btn btn-white dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Ordenar por: <span data-order>Ordem alfabética (A-Z)</span>
                        </button>
                        <ul class="dropdown-menu">
                            <li><button type="button" class="dropdown-item active">Ordem alfabética (A-Z)</button></li>
                            <li><button type="button" class="dropdown-item">Ordem alfabética (Z-A)</button></li>
                            <li><button type="button" class="dropdown-item">Maior preço</button></li>
                            <li><button type="button" class="dropdown-item">Menor preço</button></li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="border-bottom p-3">
                <div class="d-flex align-items-start flex-wrap gap-2">
                    <?php foreach ($products as $product) : ?>
                        <a class="card card-body p-2 text-decoration-none" href="<?= base_url("category/" . strtolower($category->name) . "/products/{$product->product_id}") ?>" style="max-width: 297px">
                            <div class="ratio ratio-1x1">
                                <img src="<?= base_url("upload/{$product->image}") ?>" alt="" class="object-fit-cover img-fluid rounded">
                            </div>

                            <p class="link-primary m-0 fw-100 mt-3"><?= $product->name ?></p>
                            <p class="link-primary m-0 fw-bold fs-5"><?= format_currency($product->price) ?></p>
                        </a>
                    <?php endforeach ?>
                </div>
            </div>

            <div class="d-flex justify-content-center">
                <nav aria-label="Page navigation example">
                    <ul class="pagination mt-3">
                        <li class="page-item">
                            <a class="page-link" href="#" aria-label="Previous">
                                <span aria-hidden="true">&laquo;</span>
                            </a>
                        </li>
                        <li class="page-item"><a class="page-link" href="#">1</a></li>
                        <li class="page-item"><a class="page-link" href="#">2</a></li>
                        <li class="page-item"><a class="page-link" href="#">3</a></li>
                        <li class="page-item">
                            <a class="page-link" href="#" aria-label="Next">
                                <span aria-hidden="true">&raquo;</span>
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>

    <script src="<?= base_url("js/category-home.js") ?>"></script>