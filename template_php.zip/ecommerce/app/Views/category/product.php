    <div class="container-fluid px-5 mb-5">
        <div class="d-flex gap-2">
            <div class="col-md-6 card card-body">
                <div class="row">
                    <div class="col-md-2">
                        <div class="d-flex flex-column gap-1" data-secondary-images>
                            <?php if ($product->secondaryImages) :  ?>
                                <?php foreach ($product->secondaryImages as $image) :  ?>
                                    <button type="button" class="btn btn-light p-1 ratio ratio-1x1" style="width: 100%; max-width: 72px;">
                                        <img src="<?= base_url("upload/{$image->url}") ?>" alt="Imagem do produto" class="object-fit-cover img-fluid rounded">
                                    </button type="button">
                                <?php endforeach ?>
                            <?php else : ?>
                                <span class="text-muted text-center p-2">Nenhuma outra imagem para exibir</span>
                            <?php endif ?>
                        </div>
                    </div>
                    <div class="col-md-10">
                        <div class="ratio ratio-1x1 text-center">
                            <img src="<?= base_url("upload/{$product->primaryImage->url}") ?>" alt="Imagem do produto" class="object-fit-cover img-fluid rounded" data-primary-image>
                        </div>
                    </div>
                </div>

                <div class="card card-body">
                    <p class="m-0"><?= $product->description ?></p>
                </div>
            </div>
            <div class="col-md-6 card">
                <div class="card-header bg-white">
                    <h2><?= $product->name ?></h2>
                </div>
                <div class="card-body">
                    <form action="#" method="post" id="add-cart-form">
                        <input type="hidden" name="id" value="<?= $product->product_id ?>">

                        <div class="form-group mb-3" data-size-group>
                            <label>Tamanho</label>

                            <div class="d-flex align-items-start gap-1">
                                <button type="button" class="btn btn-secondary" style="max-width: 40px; max-height: 40px;">P</button>
                                <button type="button" class="btn btn-secondary" style="max-width: 40px; max-height: 40px;">P</button>
                                <button type="button" class="btn btn-secondary" style="max-width: 40px; max-height: 40px;">P</button>
                            </div>

                            <input type="hidden" name="size" id="product-size">
                        </div>

                        <div class="form-group mb-5">
                            <label for="product-quantity">Quantidade</label>
                            <select name="quantity" id="product-quantity" class="form-select">
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                            </select>
                        </div>
                    </form>
                </div>

                <div class="card-footer bg-white">
                    <button type="submit" form="add-cart-form" class="btn btn-primary">Adicionar produto ao carrinho</button>
                </div>
            </div>
        </div>
    </div>

    <script src="<?= base_url("js/product.js") ?>"></script>