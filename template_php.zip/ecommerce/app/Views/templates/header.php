<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="<?= base_url("bootstrap/css/bootstrap.css") ?>">
    <link rel="stylesheet" href="<?= base_url("bootstrap/icons/bootstrap-icons.css") ?>">

    <script src="<?= base_url("bootstrap/js/jquery.min.js") ?>"></script>
    <script src="<?= base_url("bootstrap/js/bootstrap.js") ?>"></script>

    <title><?= $title ?></title>
</head>

<body>
    <header>
        <nav class="navbar text-bg-dark">
            <div class="container-fluid px-5 py-2">
                <div class="d-flex justify-content-between align-items-center w-100 gap-3">
                    <a class="navbar-brand link-light" href="<?= base_url() ?>">Navbar</a>

                    <form class="w-100" role="search">
                        <div class="input-group">
                            <input class="form-control" type="search" placeholder="Search" aria-label="Search">
                            <button class="btn btn-primary" type="submit"><i class="bi bi-search"></i></button>
                        </div>
                    </form>

                    <button class="position-relative btn btn-dark" type="submit" data-bs-toggle="offcanvas" data-bs-target="#cartOffcanvas" aria-controls="cartOffcanvas">
                        <i class="bi bi-cart"></i>
                        <span class="position-absolute badge rounded-pill bg-danger" style="top: -1px; right: -1px">3</span>
                    </button>
                </div>
            </div>
        </nav>
    </header>

    <div class="offcanvas offcanvas-end text-bg-dark" tabindex="-1" id="cartOffcanvas" aria-labelledby="cartOffcanvasLabel">
        <div class="offcanvas-header">
            <h5 class="offcanvas-title" id="cartOffcanvasLabel">Carrinho</h5>
            <button type="button" class="btn-close text-light" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
            <div class="list-group">
                <a class="list-group-item list-group-item-action d-flex align-items-start gap-3" href="#">
                    <div class="ratio ratio-1x1" style="max-width: 48px;">
                        <img src="https://source.unsplash.com/random/?shirt" alt="Uma camisa" class="object-fit-cover img-fluid rounded">
                    </div>

                    <div>
                        <p class="m-0 fw-bold">Nome do produto</p>
                        <p class="m-0" style="font-size: .9rem;">R$200,00</p>
                    </div>
                </a>
            </div>
        </div>
    </div>