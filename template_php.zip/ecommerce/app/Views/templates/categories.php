    <div class="container-fluid px-5 py-2 border-bottom">
        <nav class="d-flex gap-3 justify-content-center mx-auto">
            <a href="<?= base_url() ?>" class="text-decoration-none text-capitalize">Página inicial</a>
            <?php foreach ($categories as $category) : ?>
                <a href="<?= base_url("category/" . strtolower($category->name)) ?>" class="text-decoration-none text-capitalize"><?= $category->name ?></a>
            <?php endforeach ?>
        </nav>
    </div>