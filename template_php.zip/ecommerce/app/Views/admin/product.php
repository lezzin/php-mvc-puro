<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="<?= base_url("bootstrap/css/bootstrap.css") ?>">
    <link rel="stylesheet" href="<?= base_url("bootstrap/icons/bootstrap-icons.css") ?>">

    <script src="<?= base_url("bootstrap/js/jquery.min.js") ?>" defer></script>
    <script src="<?= base_url("bootstrap/js/bootstrap.js") ?>" defer></script>

    <script src="<?= base_url("js/admin/admin.js") ?>" defer></script>
    <script src="<?= base_url("js/admin/product.js") ?>" defer></script>

    <title>Administração | ecommerce</title>
</head>

<body data-url="<?= base_url() ?>">
    <div class="container-fluid p-0 row">
        <div class="col-md-3">
            <?= view("admin/templates/sidebar", ["current" => "product"]) ?>
        </div>

        <div class="col-md-9 p-3">
            <h2 class="h4 mb-3">Produto</h2>

            <div class="card card-body">
                <form class="needs-validation" novalidate method="post" action="<?= base_url("product/actions/save") ?>" id="product-form" enctype="multipart/form-data">
                    <div class="form-group mb-3">
                        <label for="product-category">Categoria</label>
                        <select name="category" data-product-category class="form-select" required>
                            <option>Carregando...</option>
                        </select>
                        <div class="invalid-feedback">
                            Insira a categoria!
                        </div>
                    </div>

                    <div class="form-group mb-3">
                        <label for="product-name">Nome</label>
                        <input type="text" name="name" id="product-name" class="form-control" placeholder="Camisa masculina básica" required>
                        <div class="invalid-feedback">
                            Insira o nome do produto!
                        </div>
                    </div>

                    <div class="form-group mb-3">
                        <label for="product-price">Preço</label>
                        <input type="text" name="price" id="product-price" class="form-control" placeholder="R$0,00" required>
                        <div class="invalid-feedback">
                            Insira o preço do produto!
                        </div>
                    </div>

                    <div class="form-group mb-3">
                        <label for="product-description">Descrição</label>
                        <textarea name="description" id="product-description" class="form-control" placeholder="Camisa masculina de algodão e gola alta" rows="3"></textarea>
                        <div class="invalid-feedback">
                            Insira a descrição do produto!
                        </div>
                    </div>

                    <div class="border rounded p-3 mb-3">
                        <div class="form-group mb-3">
                            <label for="product-image-quantity">Quantidade de imagens</label>
                            <select id="product-image-quantity" aria-labelledby="#product-image-label" class="form-control">
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                            </select>
                        </div>

                        <div id="product-images-container">
                            <div class="form-group mb-1">
                                <label for="product-image-1">Imagem 1</label>
                                <input type="file" name="image[]" id="product-image-1" class="form-control" required>
                                <div class="invalid-feedback">
                                    Insira a imagem 1!
                                </div>
                            </div>
                        </div>

                        <span class="form-text" id="product-image-label">* A primeira imagem será a principal</span>
                    </div>

                    <button class="btn btn-primary" type="submit">Adicionar produto</button>
                </form>
            </div>

            <div class="card card-body mt-3">
                <table class="table table-sm table-hover" id="products-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nome</th>
                            <th>Preço</th>
                            <th>Descrição</th>
                            <th>Mais</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>
                                <p class="m-1 placeholder-glow">
                                    <span class="placeholder col-1"></span>
                                </p>
                            </td>
                            <td>
                                <p class="m-1 placeholder-glow">
                                    <span class="placeholder col-3"></span>
                                </p>
                            </td>
                            <td>
                                <p class="m-1 placeholder-glow">
                                    <span class="placeholder col-2"></span>
                                </p>
                            </td>
                            <td>
                                <p class="m-1 placeholder-glow">
                                    <span class="placeholder col-2"></span>
                                </p>
                            </td>
                            <td>
                                <p class="m-1 placeholder-glow">
                                    <span class="placeholder col-2"></span>
                                </p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="toast-container position-fixed bottom-0 end-0 p-3" id="toast-container"></div>
</body>

</html>