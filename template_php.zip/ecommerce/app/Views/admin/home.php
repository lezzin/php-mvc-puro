<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="<?= base_url("bootstrap/css/bootstrap.css") ?>">
    <link rel="stylesheet" href="<?= base_url("bootstrap/icons/bootstrap-icons.css") ?>">

    <script src="<?= base_url("bootstrap/js/jquery.min.js") ?>"></script>
    <script src="<?= base_url("bootstrap/js/bootstrap.js") ?>"></script>

    <title>Administração | ecommerce</title>
</head>

<body>
    <div class="container-fluid p-0 row">
        <div class="col-md-3">
            <?= view("admin/templates/sidebar", ["current" => "home"]) ?>
        </div>

        <div class="col-md-9 p-3">
            <h2 class="h4 mb-3">Início</h2>

            <div class="row">
                <div class="col-md-3">
                    <div class="card card-body text-bg-danger">
                        <div class="d-flex justify-content-between align-items-start gap-2">
                            <p class="fs-5 m-0">15 vendas</p>
                            <span class="display-4 opacity-25"><i class="bi bi-basket"></i> </span>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card card-body text-bg-success">
                        <div class="d-flex justify-content-between align-items-start gap-2">
                            <p class="fs-5 m-0"> 15 usuários</p>
                            <span class="display-4 opacity-25"><i class="bi bi-people"></i> </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>