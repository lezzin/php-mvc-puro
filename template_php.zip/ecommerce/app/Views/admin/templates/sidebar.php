            <div class="fixed-start d-flex flex-column text-dark bg-light min-vh-100 h-100 p-3 border border-right">
                <a href="<?= base_url("admin") ?>" class="text-dark text-decoration-none">
                    <span class="fs-5">E-commerce</span>
                </a>
                <hr>
                <ul class="nav nav-pills flex-column mb-auto">
                    <li class="nav-item">
                        <a href="<?= base_url("admin") ?>" class="nav-link <?= $current == "home" ? "active" : "" ?>">Início</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?= base_url("admin/category") ?>" class="nav-link <?= $current == "category" ? "active" : "" ?>">Categorias</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?= base_url("admin/product") ?>" class="nav-link <?= $current == "product" ? "active" : "" ?>">Produtos</a>
                    </li>
                </ul>
                <hr>
                <button class="d-block w-100 btn btn-sm btn-outline-danger">Sair</button>
            </div>