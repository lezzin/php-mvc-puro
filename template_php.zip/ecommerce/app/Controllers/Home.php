<?php

namespace App\Controllers;

use App\Models\CategoryModel;
use App\Models\ProductModel;

class Home extends BaseController
{
    public function __construct()
    {
        helper("currency");
    }

    public function index(): string
    {
        $categories = (new CategoryModel)->asObject()->findAll();
        $products = (new ProductModel)
            ->join('product_image', 'product_image.product_id = product.product_id')
            ->join('category', 'category.category_id = product.category_id')
            ->select('product.*, product_image.url AS image, category.name AS category')
            ->groupBy('product.product_id')
            ->asObject()
            ->findAll(5);

        $headerData =  ["title" => "Início | e-commerce"];
        $categoriesData = ["categories" => $categories];
        $homeData = [
            "products" => $products,
            "categories" => $categories
        ];

        return view('templates/header', $headerData)
            . view('templates/categories', $categoriesData)
            . view('home/home', $homeData);
    }
}
