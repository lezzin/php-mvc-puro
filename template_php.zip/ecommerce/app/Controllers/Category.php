<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;
use Exception;
use App\Models\CategoryModel;
use App\Models\ProductImageModel;
use App\Models\ProductModel;

class Category extends BaseController
{
    protected $model;
    protected $productModel;
    protected $productImageModel;
    protected $categoryModel;

    public function __construct()
    {
        $this->model = new CategoryModel();
        $this->productModel = new ProductModel();
        $this->productImageModel = new ProductImageModel();
        helper('currency');
    }

    public function category($name)
    {
        $category = $this->model->where("name", $name)->asObject()->find()[0];
        if (!$category) return redirect()->to('error');

        $products = $this->productModel->where("category_id", $category->category_id)->findAll();
        foreach ($products as &$product) {
            $productImage = $this->productImageModel->asObject()->where("product_id", $product->product_id)->first();
            $product->image = $productImage ? $productImage->url : "";
        }

        $headerData =  ["title" => "{$category->name} | Ecommerce"];
        $categoriesData = ["categories" => $this->model->asObject()->findAll()];
        $homeData = ["products" => $products, "category" => $category];
        $breadcrumdData = [
            "breadcrumbLinks" => [
                ['name' => $category->name, 'active' => true]
            ]
        ];

        return view("templates/header", $headerData)
            . view('templates/categories', $categoriesData)
            . view("templates/breadcrumb", $breadcrumdData)
            . view("category/home", $homeData);
    }

    public function product($category, $product)
    {
        $category = $this->model->where("name", $category)->asObject()->find()[0];
        if (!$category) return redirect()->to('error');

        $product = $this->productModel->where("product_id", $product)->first();
        $productImages = $this->productImageModel->asObject()->select("url")->where("product_id", $product->product_id)->findAll();
        $product->primaryImage = $productImages[0];
        array_shift($productImages);
        $product->secondaryImages = $productImages;

        $headerData =  ["title" => "{$product->name} | Ecommerce"];
        $categoriesData = ["categories" => $this->model->asObject()->findAll()];
        $productData = ["product" => $product, "category" => $category];
        $breadcrumdData = [
            "breadcrumbLinks" => [
                ['name' => $category->name, 'active' => false, 'url' => "category/{$category->name}"],
                ['name' => $product->name, 'active' => true]
            ]
        ];

        return view("templates/header", $headerData)
            . view('templates/categories', $categoriesData)
            . view("templates/breadcrumb", $breadcrumdData)
            . view("category/product", $productData);
    }

    public function save()
    {
        $response = [];
        $id = $this->request->getPost("id");
        $fileName = $this->uploadFile('image');

        if ($id) {
            $response = $this->updateCategory($id, $fileName);
        } else {
            $response = $this->addCategory($fileName);
        }

        return $this->response->setJSON($response);
    }

    private function uploadFile($fieldName)
    {
        if ($this->request->getFile($fieldName) && $this->request->getFile($fieldName)->isValid()) {
            $file = $this->request->getFile($fieldName);
            $fileName = $file->getRandomName();
            $file->move('upload', $fileName);
            return $fileName;
        }
        return null;
    }

    private function updateCategory($id, $fileName)
    {
        $category = $this->model->find($id);
        if (!$category) {
            return [
                "status" => "error",
                "message" => "Categoria não encontrada."
            ];
        }

        $data = [
            'name'  => $this->request->getPost("name") ?? $category->name,
            'image' => $fileName ?? $category->image
        ];

        try {
            $this->model->update($id, $data);
            return [
                "status" => "success",
                "message" => "Categoria atualizada com sucesso!"
            ];
        } catch (Exception $e) {
            return [
                "status" => "error",
                "message" => "Erro ao atualizar categoria: " . $e->getMessage()
            ];
        }
    }

    private function addCategory($fileName)
    {
        $data = [
            'name'  => $this->request->getPost("name") ?? null,
            'image' => $fileName
        ];

        try {
            $this->model->save($data);
            return [
                "status" => "success",
                "message" => "Categoria cadastrada com sucesso!"
            ];
        } catch (Exception $e) {
            return [
                "status" => "error",
                "message" => "Erro ao salvar categoria: " . $e->getMessage()
            ];
        }
    }

    public function get()
    {
        $categories = $this->model->asObject()->findAll();
        return $this->response->setJSON($categories);
    }

    public function delete($id)
    {
        $response = [];

        $imageToDelete = $this->model->select("image")->where("category_id", $id)->first()->image;
        if ($imageToDelete and file_exists("upload/" . $imageToDelete)) {
            unlink("upload/" . $imageToDelete);
        }

        try {
            $this->model->delete($id);
            $response = [
                "status" => "success",
                "message" => "Categoria deletada com sucesso!"
            ];
        } catch (Exception $e) {
            $response = [
                "status" => "success",
                "message" => "Erro ao deletar categoria: " . $e->getMessage()
            ];
        }

        return $this->response->setJSON($response);
    }
}
