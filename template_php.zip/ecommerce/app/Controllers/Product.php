<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\ProductModel;
use App\Models\ProductImageModel;
use Exception;

class Product extends BaseController
{
    protected $model;
    protected $imageModel;

    public function __construct()
    {
        $this->model = new ProductModel();
        $this->imageModel = new ProductImageModel();
    }

    private function handleImagesUpload($productId)
    {
        if ($this->request->getFiles('image')) {
            $files = $this->request->getFiles('image')['image'];

            foreach ($files as $file) {
                $newName = $file->getRandomName();
                $file->move('upload', $newName);

                $imageData = [
                    'product_id' => $productId,
                    "url"        => $newName,
                ];

                $this->imageModel->save($imageData);
            }
        }
    }

    public function save()
    {
        $response = [];

        $id = $this->request->getPost("id");
        $data = [
            'category_id'  => $this->request->getPost("category"),
            'name'         => $this->request->getPost("name"),
            'description'  => $this->request->getPost("description"),
            'price'        => $this->request->getPost("price"),
        ];

        try {
            if ($id) {
                $this->model->update($id, $data);
                $response = [
                    "status"  => "success",
                    "message" => "Produto atualizado com sucesso!"
                ];
            } else {
                if ($this->model->save($data)) {
                    $id = $this->model->getInsertID();
                    $this->handleImagesUpload($id);
                    $response = [
                        "status"  => "success",
                        "message" => "Produto cadastrado com sucesso!"
                    ];
                }
            }
        } catch (Exception $e) {
            $response = [
                "status"  => "error",
                "message" => "Erro ao salvar produto: " . $e->getMessage()
            ];
        }

        return $this->response->setJSON($response);
    }

    public function get()
    {
        $products = $this->model->findAll();

        foreach ($products as $product) {
            $productImages = $this->imageModel->asObject()->select("url")->where("product_id", $product->product_id)->findAll();
            $product->primaryImage = $productImages[0] ?? null;
            array_shift($productImages);
            $product->secondaryImages = $productImages;
        }

        return $this->response->setJSON($products);
    }

    public function delete($id)
    {
        $images = $this->imageModel->where("product_id", $id);

        if ($images->countAllResults()) {
            $imagesToDelete = $images->findAll();
            foreach ($imagesToDelete as $image) {
                if (file_exists("upload/" . $image->url)) {
                    unlink("upload/" . $image->url);
                }
            }

            $this->imageModel->where("product_id", $id)->delete();
        }

        try {
            $this->model->delete($id);

            $response = [
                "status"  => "success",
                "message" => "Produto deletado com sucesso!"
            ];
        } catch (Exception $e) {
            $response = [
                "status"  => "error",
                "message" => "Erro ao deletar produto: " . $e->getMessage()
            ];
        }

        return $this->response->setJSON($response);
    }
}
