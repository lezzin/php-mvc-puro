<?php

namespace App\Controllers;

class Admin extends BaseController
{
    public function index(): string
    {
        return view('admin/home');
    }

    public function category(): string
    {
        return view('admin/category');
    }

    public function product(): string
    {
        return view('admin/product');
    }
}
