<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->group('', function($routes) {
    $routes->get('/', 'Home::index');

    $routes->group('admin', function($routes) {
        $routes->get('', 'Admin::index');
        $routes->get('category', 'Admin::category');
        $routes->get('product', 'Admin::product');
    });

    $routes->group('category', function($routes) {
        $routes->post('actions/save', 'Category::save');
        $routes->get('actions/get', 'Category::get');
        $routes->get('(:segment)', 'Category::category/$1');
        $routes->get('(:segment)/products/(:segment)', 'Category::product/$1/$2');
        $routes->delete('actions/delete/(:num)', 'Category::delete/$1');
    });

    $routes->group('product', function($routes) {
        $routes->post('actions/save', 'Product::save');
        $routes->get('actions/get', 'Product::get');
        $routes->delete('actions/delete/(:num)', 'Product::delete/$1');
    });
});
