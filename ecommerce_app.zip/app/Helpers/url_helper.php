<?php

/**
 * Format URL to better readability
 */
function url_format($url): string
{
    $decodedUrl = urldecode($url);
    $withoutSpacesUrl = str_replace(' ', '-', $decodedUrl);
    $lowerCaseUrl = strtolower($withoutSpacesUrl);

    return $lowerCaseUrl;
}

function get_original_url($url) {
    $withSpaceUrl = str_replace('-', ' ', $url);
    return $withSpaceUrl;
}