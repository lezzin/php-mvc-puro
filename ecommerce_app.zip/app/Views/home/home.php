    <?= view("templates/banner", ["banner_url" => $banner_url]) ?>

    <div class="container-fluid px-5 mb-5">
        <section>
            <h3 class="h4 mt-4">Categorias</h3>

            <div class="d-flex flex-wrap gap-2 mt-3">
                <?php foreach ($categories as $category) : ?>
                    <a class="p-2 text-decoration-none" href="<?= base_url("category/" . url_format($category->name)) ?>">
                        <div class="ratio ratio-1x1" style="width: 200px">
                            <img src="<?= base_url("upload/{$category->image}") ?>" alt="<?= $category->name ?>" class="shadow-primary-hover object-fit-cover img-fluid rounded-circle border">
                        </div>

                        <p class="link-dark mt-2 mb-0 text-center"><?= $category->name ?></p>
                    </a>
                <?php endforeach ?>
            </div>
        </section>

        <section>
            <h3 class="h4 mt-4">Produtos destaques</h3>

            <?php if (!empty($products)) : ?>
                <?= view("templates/products_list", ["products" => $products, "small" => true]) ?>
            <?php endif ?>
        </section>
    </div>

    <script src="<?= base_url("js/home/home.js") ?>" defer type="module"></script>