<div class="d-flex align-items-stretch flex-wrap gap-2" id="product-container">
    <?php foreach ($products as $product) : ?>
        <a class="card card-body p-2 text-decoration-none shadow-primary-hover" href="<?= base_url("category/" . url_format($product->category) . "/products/" . url_format($product->name)) ?>" style="max-width: <?= (isset($small) && $small ? "230px" : "297px") ?>">
            <div class="ratio ratio-1x1">
                <img src="<?= base_url("upload/{$product->image}") ?>" alt="" class="object-fit-cover img-fluid rounded">
            </div>

            <p class="link-primary mt-3 text-truncate text-nowrap" style="max-width: 100%"><?= $product->name ?></p>
            <p class="link-primary mb-0 fw-bold fs-5"><?= format_currency($product->price) ?></p>
        </a>
    <?php endforeach ?>
</div>