        <div class="container-fluid px-5 mb-3" style="margin-top: 8rem">
            <div class="row">
                <div class="col-md-4 col-12">
                    <h4 class="h6 mb-3 text-uppercase">Políticas</h4>
                    <ul class="list-unstyled mb-0">
                        <li><a href="#" class="link-dark py-1 text-decoration-none">Trocas e Devolução</a></li>
                        <li><a href="#" class="link-dark py-1 text-decoration-none">Termos de serviço</a></li>
                        <li><a href="#" class="link-dark py-1 text-decoration-none">Política de Privacidade</a></li>
                    </ul>
                </div>
                <div class="col-md-4 col-12">
                    <h4 class="h6 mb-3 text-uppercase">Menu principal</h4>
                    <ul class="list-unstyled mb-0">
                        <li>
                            <a href="<?= base_url() ?>" class="link-dark py-1 text-decoration-none">Início</a>
                        </li>
                        <?php foreach ($categories as $category) : ?>
                            <li>
                                <a href="<?= base_url("category/" . url_format($category->name)) ?>" class="link-dark py-1 text-decoration-none"><?= $category->name ?></a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <div class="col-md-4 col-12">
                    <h4 class="h6 mb-3 text-uppercase">Atendimento</h4>
                    <p class="m-0">Não achou nenhum produto de seu interesse? Entre em contato:</p>
                    <ul class="list-unstyled mb-0">
                        <li>Email: email@email.com</li>
                        <li>Whatsapp: (35) 99999-9999</li>
                    </ul>
                </div>
            </div>
            <div class="d-flex justify-content-between align-items-center" style="margin-top: 4rem">
                <p class="m-0" style="font-size: .9rem">&copy; Nome da loja</p>

                <p class="m-0" style="font-size: .9rem">
                    <a class="link-dark text-decoration-none" href="https://instagram.com"><i class="bi bi-instagram"></i> Siga-nos no Instagram</a>
                </p>
            </div>
        </div>
        </main>
        </body>

        </html>