    <div class="container-fluid ps-5 pt-3 pb-2">
        <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?= base_url() ?>">Início</a></li>
                <?php foreach ($breadcrumbLinks as $link) :  ?>
                    <?php if ($link["active"]) : ?>
                        <li class="breadcrumb-item" aria-current="page"><?= $link["name"] ?></li>
                    <?php else : ?>
                        <li class="breadcrumb-item"><a href="<?= url_format(base_url($link["url"])) ?>"><?= $link["name"] ?></a></li>
                    <?php endif; ?>
                <?php endforeach ?>
            </ol>
        </nav>
    </div>