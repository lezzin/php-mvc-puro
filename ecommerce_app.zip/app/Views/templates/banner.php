    <?php if ($banner_url) : ?>
        <div class="ratio" style="aspect-ratio: 16/7;">
            <img class="img-fluid object-fit-cover" src="<?= base_url("upload/{$banner_url}") ?>" alt="Banner de promoções">
        </div>
    <?php endif ?>