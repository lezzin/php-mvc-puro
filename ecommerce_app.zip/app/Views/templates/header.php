<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="<?= base_url("css/style.css") ?>">

    <script src="<?= base_url("bootstrap/js/jquery.min.js") ?>" defer></script>
    <script src="<?= base_url("bootstrap/js/bootstrap.js") ?>" defer></script>
    <script src="<?= base_url("js/header/header.js") ?>" defer type="module"></script>

    <title><?= $title ?></title>
</head>

<body data-url="<?= base_url() ?>">
    <header>
        <?php if ($config && $config->top_message) : ?>
            <div class="text-bg-primary py-1 text-center text-uppercase">
                <p class="m-0"><?= $config->top_message ?></p>
            </div>
        <?php endif ?>

        <nav class="navbar text-bg-dark">
            <div class="container-fluid px-5 py-2">
                <div class="d-flex justify-content-between align-items-center w-100 gap-3">
                    <a class="navbar-brand link-light" href="<?= base_url() ?>">Navbar</a>

                    <form class="d-flex w-100 mx-auto position-relative" role="search" id="search-product-form" style="max-width: 600px">
                        <div class="input-group">
                            <input class="form-control" type="search" placeholder="Pesquisar produto" aria-label="Search">
                            <button class="btn btn-primary" type="submit"><i class="bi bi-search"></i></button>
                        </div>

                        <div class="position-absolute top-100 w-100 mt-1">
                            <div class="list-group"></div>
                        </div>
                    </form>

                    <div>
                        <?php if (!session()->has("user")) : ?>

                            <a class="btn btn-primary" href="<?= base_url("user/login") ?>" role="button">
                                <i class="bi bi-box-arrow-right"></i>
                            </a>

                        <?php else : ?>

                            <?php if (session()->get("user")->user_type == "customer") : ?>
                                <button class="position-relative btn btn-dark" type="submit" data-bs-toggle="offcanvas" data-bs-target="#cartOffcanvas" aria-controls="cartOffcanvas" id="cart-button">
                                    <i class="bi bi-cart"></i>
                                    <span class="position-absolute badge rounded-pill bg-danger" style="top: -1px; right: -1px"></span>
                                </button>
                            <?php else : ?>
                                <a class="btn btn-primary" href="<?= base_url("admin") ?>" role="button">
                                    Administração
                                </a>
                            <?php endif ?>

                            <a class="btn btn-danger" href="<?= base_url("user/logout") ?>" role="button">
                                <i class="bi bi-box-arrow-left"></i>
                            </a>
                        <?php endif ?>
                    </div>
                </div>
            </div>
        </nav>
    </header>

    <div class="offcanvas offcanvas-end text-bg-light" tabindex="-1" id="cartOffcanvas" aria-labelledby="cartOffcanvasLabel">
        <div class="offcanvas-header">
            <h5 class="offcanvas-title" id="cartOffcanvasLabel">Carrinho</h5>
            <button type="button" class="btn-close text-light" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
            <ul class="list-group"></ul>
            <a class="btn btn-dark mt-3 d-block w-100" role="button" href="<?= base_url("cart") ?>">Acessar carrinho</a>
        </div>
    </div>

    <main>