    <div class="container-fluid px-5 mb-5">
        <div class="row">
            <div class="col-md-6 col-12">
                <div class="card card-body">
                    <?php if ($product->secondaryImages) : ?>
                        <div class="row">
                            <div class="col-md-2">
                                <div class="d-flex flex-column gap-1" data-secondary-images>
                                    <?php if ($product->secondaryImages) :  ?>
                                        <?php foreach ($product->secondaryImages as $image) :  ?>
                                            <button type="button" class="btn btn-light p-1 ratio ratio-1x1" style="width: 100%; max-width: 72px;">
                                                <img src="<?= base_url("upload/{$image->url}") ?>" alt="Imagem do produto" class="object-fit-cover img-fluid rounded">
                                            </button type="button">
                                        <?php endforeach ?>
                                    <?php endif ?>
                                </div>
                            </div>
                            <div class="col-md-10">
                                <div class="ratio ratio-1x1 text-center">
                                    <img src="<?= base_url("upload/{$product->primaryImage->url}") ?>" alt="Imagem do produto" class="object-fit-cover img-fluid rounded" data-primary-image>
                                </div>
                            </div>
                        </div>
                    <?php else : ?>
                        <div class="ratio ratio-1x1 text-center">
                            <img src="<?= base_url("upload/{$product->primaryImage->url}") ?>" alt="Imagem do produto" class="object-fit-cover img-fluid rounded" data-primary-image>
                        </div>
                    <?php endif ?>
                </div>

                <div class="card card-body mt-2">
                    <p class="m-0"><?= $product->description ?></p>
                </div>
            </div>
            <div class="col-md-6 col-12 mt-2 mt-md-0">
                <div class="card">
                    <div class="card-header bg-white">
                        <h2 class="h3"><?= $product->name ?></h2>
                    </div>
                    <?php if (sizeof($product->stocks) >= 1) : ?>
                        <div class="card-body">
                            <form action="<?= base_url("/cart/actions/save") ?>" method="post" id="add-cart-form">
                                <input type="hidden" name="product_id" value="<?= $product->product_id ?>">

                                <div class="row">
                                    <div class="col-md-6 col-12">
                                        <div class="form-group mb-3" data-size-group>
                                            <label>Tamanho</label>

                                            <select name="size" id="product-size" class="form-select">
                                                <?php foreach ($product->stocks as $stock) : ?>
                                                    <option data-quantity="<?= $stock->quantity ?>"><?= $stock->size ?></option>
                                                <?php endforeach ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-md-6 col-12">
                                        <div class="form-group mb-5">
                                            <label for="product-quantity">Quantidade</label>
                                            <select name="quantity" id="product-quantity" class="form-select" required></select>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>

                        <div class="card-footer bg-white">
                            <?php if (session()->has("user") and session("user")->user_type != "admin") : ?>
                                <button type="submit" form="add-cart-form" class="btn btn-primary">Adicionar produto ao carrinho</button>
                            <?php else : ?>
                                <div class="alert alert-info mb-0 py-2 text-center">
                                    <p class="m-0"><i class="bi bi-exclamation-circle"></i> Você está logado como administrador</p>
                                </div>
                            <?php endif ?>
                        </div>
                    <?php else : ?>
                        <div class="card-body">
                            <div class="alert alert-info m-0">
                                <p class="m-0"><i class="bi bi-exclamation-circle"></i> Produto indisponível</p>
                            </div>
                        </div>
                    <?php endif ?>
                </div>
            </div>
        </div>
    </div>

    <div class="toast-container position-fixed bottom-0 end-0 p-3" id="toast-container"></div>

    <script src="<?= base_url("js/category/product.js") ?>" defer type="module"></script>