    <div class="container-fluid px-5 mb-5">
        <div class="card">
            <div class="border-bottom p-3">
                <div>
                    <h2><?= ucfirst($category->name) ?></h2>
                </div>

                <?php if (!empty($products)) : ?>
                    <div class="d-flex justify-content-between align-items-center mt-1">
                        <p class="m-0">
                            <span>Mostrando <?= sizeof($products) ?> de <?= $pager->getTotal() ?> resultados</span>
                            <span>(página <?= $pager->getCurrentPage() ?> de <?= $pager->getPageCount() ?>)</span>
                        </p>

                        <div class="dropdown-center" id="order-product-filter">
                            <button class="btn btn-white dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                Ordenar por: <span data-order-display>Ordem alfabética (A-Z)</span>
                            </button>
                            <ul class="dropdown-menu">
                                <li><button type="button" class="dropdown-item active" data-order="az">Ordem alfabética (A-Z)</button></li>
                                <li><button type="button" class="dropdown-item" data-order="za">Ordem alfabética (Z-A)</button></li>
                                <li><button type="button" class="dropdown-item" data-order="highestprice">Maior preço</button></li>
                                <li><button type="button" class="dropdown-item" data-order="lowestprice">Menor preço</button></li>
                            </ul>
                        </div>
                    </div>
                <?php endif ?>
            </div>

            <div class="border-bottom p-3">
                <?php if (!empty($products)) : ?>
                    <?= view("templates/products_list", ["products" => $products]) ?>
                <?php else : ?>
                    <div class="alert alert-info text-center m-0">
                        <p class="m-0"><i class="bi bi-exclamation-circle"></i> Nenhum produto cadastrado</p>
                    </div>
                <?php endif ?>
            </div>

            <?php if (!empty($products)) : ?>
                <div class="d-flex justify-content-center mt-3">
                    <?= $pager->links('default', 'pager') ?>
                </div>
            <?php endif ?>
        </div>
    </div>

    <script src="<?= base_url("js/category/home.js") ?>" defer type="module"></script>