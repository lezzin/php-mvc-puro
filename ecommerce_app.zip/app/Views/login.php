<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="<?= base_url("bootstrap/css/bootstrap.css") ?>">
    <link rel="stylesheet" href="<?= base_url("bootstrap/icons/bootstrap-icons.css") ?>">

    <script src="<?= base_url("bootstrap/js/jquery.min.js") ?>"></script>
    <script src="<?= base_url("bootstrap/js/bootstrap.js") ?>"></script>

    <title><?= $title ?></title>
</head>

<body>
    <div class="d-flex justify-content-center align-items-center min-vh-100">
        <div class="card card-body" style="max-width: 500px;">
            <form class="row g-3" action="<?= base_url("user/login") ?>" method="post" id="login-form">
                <?php if (session()->getFlashdata("message")) : ?>
                    <div class="col-12">
                        <div class="alert alert-info">
                            <p class="m-0"><?= session()->getFlashdata("message") ?></p>
                        </div>
                    </div>
                <?php endif ?>

                <h2>Login</h2>

                <div class="col-12">
                    <label for="username">Email</label>
                    <input type="email" class="form-control" id="email" name="email" placeholder="joao@email.com" required>
                </div>

                <div class="col-12">
                    <label for="password">Senha</label>
                    <input type="password" class="form-control" id="password" name="password" placeholder="********" required>
                </div>

                <div class="col-12">
                    <button class="d-block w-100 btn btn-primary" type="submit">Acessar conta</button>
                    <a href="<?= base_url("/user/register") ?>" class="d-block w-100 text-center text-decoration-none link-primary mt-2">Não possuo conta</a>
                </div>
            </form>
        </div>
    </div>

    <div class="toast-container position-fixed bottom-0 end-0 p-3" id="toast-container"></div>
    <script src="<?= base_url("js/user/user.js") ?>" type="module"></script>
</body>

</html>