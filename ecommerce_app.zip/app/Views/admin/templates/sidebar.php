            <div class="fixed-start d-flex flex-column text-dark bg-light min-vh-100 h-100 p-3 border border-right">
                <a href="<?= base_url() ?>" class="text-dark text-decoration-none">
                    <span class="fs-5">E-commerce</span>
                </a>
                <hr>
                <ul class="nav nav-pills flex-column mb-auto">
                    <li class="nav-item">
                        <a href="<?= base_url("admin") ?>" class="nav-link <?= $current == "home" ? "active" : "" ?>"><i class="bi bi-graph-up"></i> Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?= base_url("admin/category") ?>" class="nav-link <?= $current == "category" ? "active" : "" ?>"><i class="bi bi-list"></i> Categorias</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?= base_url("admin/product") ?>" class="nav-link <?= $current == "product" ? "active" : "" ?>"><i class="bi bi-bag"></i> Produtos</a>
                    </li>
                    <li class="nav-item">
                        <a href="<?= base_url("admin/customs") ?>" class="nav-link <?= $current == "customs" ? "active" : "" ?>"><i class="bi bi-gear"></i> Configurações</a>
                    </li>
                </ul>
                <hr>

                <div class="d-flex justify-content-between align-items-center">
                    <a class="btn btn-primary" href="<?= base_url() ?>" role="button">
                        <i class="bi bi-house"></i> Página inicial
                    </a>

                    <a class="btn btn-danger" href="<?= base_url("user/logout") ?>" role="button">
                        <i class="bi bi-box-arrow-left"></i> Sair
                    </a>
                </div>
            </div>