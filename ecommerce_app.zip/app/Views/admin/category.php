<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="<?= base_url("bootstrap/css/bootstrap.css") ?>">
    <link rel="stylesheet" href="<?= base_url("bootstrap/icons/bootstrap-icons.css") ?>">

    <script src="<?= base_url("bootstrap/js/jquery.min.js") ?>" defer></script>
    <script src="<?= base_url("bootstrap/js/bootstrap.js") ?>" defer></script>

    <title>Administração | ecommerce</title>
</head>

<body data-url="<?= base_url() ?>">
    <div class="container-fluid p-0 row">
        <div class="col-md-3">
            <?= view("admin/templates/sidebar", ["current" => "category"]) ?>
        </div>

        <div class="col-md-9 p-3">
            <h2 class="h4 mb-3">Categoria</h2>

            <div class="card card-body">
                <form method="post" action="<?= base_url("category/actions/save") ?>" id="category-form" enctype="multipart/form-data">
                    <div class="form-group mb-3">
                        <label for="category-name">Nome</label>
                        <input type="text" class="form-control" name="name" id="category-name" placeholder="Camisa, camiseta..." required autocomplete="off">
                    </div>

                    <div class="form-group mb-3">
                        <label for="category-image">Imagem</label>
                        <input type="file" class="form-control" name="image" id="category-image" required autocomplete="off">
                        <small class="form-text">A imagem deve ser quadrada (proporção 1:1)</small>
                    </div>

                    <button class="btn btn-primary" type="submit">Adicionar</button>
                </form>
            </div>

            <div class="card card-body mt-3">
                <table class="table table-sm table-hover" id="categories-table">
                    <thead>
                        <tr>
                            <th>Nome</th>
                            <th>Mais</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>
                                <p class="m-1 placeholder-glow">
                                    <span class="placeholder col-1"></span>
                                    <span class="placeholder col-3"></span>
                                </p>
                            </td>
                            <td>
                                <p class="m-1 placeholder-glow">
                                    <span class="placeholder col-1"></span>
                                </p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="modal" id="modal-edit-category">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Editar categoria</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form method="post" action="<?= base_url("category/actions/save") ?>" id="category-edit-form" enctype="multipart/form-data">
                        <input type="hidden" name="id" id="edit-category-id">

                        <div class="form-group mb-3">
                            <label for="category-name">Nome</label>
                            <input type="text" class="form-control" name="name" id="edit-category-name" placeholder="Camisa, camiseta..." required autocomplete="off">
                        </div>

                        <div class="form-group mb-3">
                            <label for="edit-category-image">Imagem</label>
                            <input type="file" class="form-control" name="image" id="edit-category-image" autocomplete="off">
                            <small class="form-text">A imagem deve ser quadrada (proporção 1:1)</small>
                        </div>

                        <button class="btn btn-primary" type="submit">Concluir edição</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="toast-container position-fixed bottom-0 end-0 p-3" id="toast-container"></div>
    <script src="<?= base_url("js/admin/category.js") ?>" defer type="module"></script>
</body>

</html>