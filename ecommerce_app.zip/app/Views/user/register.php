<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="<?= base_url("bootstrap/css/bootstrap.css") ?>">
    <link rel="stylesheet" href="<?= base_url("bootstrap/icons/bootstrap-icons.css") ?>">

    <script src="<?= base_url("bootstrap/js/jquery.min.js") ?>"></script>
    <script src="<?= base_url("bootstrap/js/bootstrap.js") ?>"></script>

    <title><?= $title ?></title>
</head>

<body>
    <div class="container-fluid my-5">
        <div class="d-flex justify-content-center">
            <div class="card card-body" style="max-width: 500px;">
                <form class="row g-3" method="post" action="<?=  base_url("/user/register") ?>" id="register-form">
                    <h2>Registrar-se</h2>

                    <div class="col-12">
                        <label for="username">Nome de usuário</label>
                        <div class="input-group">
                            <span class="input-group-text" id="username-prepend">@</span>
                            <input type="text" class="form-control" id="username" name="username" placeholder="joaozinho" required>
                        </div>
                    </div>

                    <div class="col-12">
                        <label for="email">Email</label>
                        <input type="email" class="form-control" id="email" name="email" placeholder="joao@email.com" required>
                    </div>

                    <div class="col-12">
                        <label for="password">Senha</label>
                        <input type="password" class="form-control" id="password" name="password" placeholder="********" required>
                    </div>

                    <div class="col-12">
                        <label for="full_name">Nome completo</label>
                        <input type="text" class="form-control" id="full_name" name="full_name" placeholder="João da Silva" required>
                    </div>

                    <div class="col-12">
                        <label for="phone_number">Telefone</label>
                        <input type="tel" class="form-control" id="phone_number" name="phone_number" placeholder="(35) 99999-9999" required>
                    </div>

                    <div class="col-12">
                        <label for="address">Endereço</label>
                        <input type="text" class="form-control" id="address" name="address" placeholder="Av." required>
                    </div>

                    <div class="col-md-8 col-12">
                        <label for="district">Bairro</label>
                        <input type="text" class="form-control" id="district" name="district" placeholder="Av." required>
                    </div>

                    <div class="col-md-4 col-12">
                        <label for="house_number">Número</label>
                        <input type="number" class="form-control" id="house_number" name="house_number" placeholder="1" required>
                    </div>

                    <div class="col-12">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="checkbox" required>
                            <label class="form-check-label" for="checkbox">
                                Li e aceito os termos e condições
                            </label>
                        </div>
                    </div>
                    <div class="col-12">
                        <button class="d-block w-100 btn btn-primary" type="submit">Criar conta</button>
                        <a href="<?= base_url("/user/login") ?>" class="d-block w-100 text-center text-decoration-none link-primary mt-2">Já possui uma conta?</a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="toast-container position-fixed bottom-0 end-0 p-3" id="toast-container"></div>
    <script src="<?= base_url("js/user/user.js") ?>" type="module"></script>
</body>

</html>