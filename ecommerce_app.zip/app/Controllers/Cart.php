<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\CartModel;
use App\Models\CategoryModel;
use App\Models\ConfigModel;
use App\Models\ProductStockModel;
use Exception;

class Cart extends BaseController
{
    protected $model;
    protected $productStockModel;

    public function __construct()
    {
        $this->model = new CartModel();
        $this->productStockModel = new ProductStockModel();
    }

    public function index()
    {
        $sessionUserId = session()->get("user")->user_id ?? null;

        $cartData = $this->model
            ->select("product.name, product.price, product_image.url, shopping_cart.size, shopping_cart.quantity, shopping_cart.cart_id")
            ->where("customer_id", $sessionUserId)
            ->join("product", "product.product_id = shopping_cart.product_id")
            ->join("product_image", "product.product_id = product_image.product_id")
            ->orderby("product.name")
            ->asObject()
            ->findAll();

        $totalCartPrice = 0;
        foreach ($cartData as $cartItem) {
            $totalCartPrice += intval($cartItem->quantity) * doubleval($cartItem->price);
        }

        $headerData =  [
            "title" => "Seu Carrinho | Ecommerce",
            "config" => (new ConfigModel)->asObject()->first() ?? null,
        ];

        $categoriesData = [
            "categories" => (new CategoryModel)->select("name")->orderBy("name")->asObject()->findAll()
        ];

        $homeData = [
            "cart" => $cartData,
            "total" => $totalCartPrice
        ];

        return view("templates/header", $headerData)
            .  view("templates/categories", $categoriesData)
            .  view("cart/home", $homeData)
            .  view("templates/footer", $categoriesData);
    }

    public function get()
    {
        $sessionUserId = session()->get("user")->user_id ?? null;

        $response = $this->model
            ->select("product.name, product.price, product_image.url, shopping_cart.size")
            ->where("customer_id", $sessionUserId)
            ->join("product", "product.product_id = shopping_cart.product_id")
            ->join("product_image", "product.product_id = product_image.product_id")
            ->groupBy("shopping_cart.size")
            ->orderBy("product.name")
            ->asObject()
            ->findAll();

        return $this->response->setJSON($response);
    }

    public function save()
    {
        if (!session()->has("user")) {
            session()->setFlashdata("message", "Você deve estar logado para acessar o carrinho");
            return redirect("login");
        }

        $data = [
            "customer_id" => session()->get("user")->user_id,
            "product_id"  => $this->request->getPost("product_id"),
            "quantity"    => $this->request->getPost("quantity"),
            "size"        => $this->request->getPost("size"),
        ];

        $response = [];
        $cart = $this->model->where("product_id", $data["product_id"])->where("size", $data["size"])->asObject()->first();

        try {
            if ($cart) {
                $newQuantity = intval($cart->quantity) + intval($data["quantity"]);
                $this->model->update($cart->cart_id, ["quantity" => $newQuantity]);

                $response = [
                    "status" => "success",
                    "message" => "Carrinho atualizado com sucesso!"
                ];
            } else {
                $this->model->insert($data);

                $response = [
                    "status" => "success",
                    "message" => "Produto adicionado ao carrinho com sucesso!"
                ];
            }
        } catch (Exception $e) {
            $response = [
                "status" => "error",
                "message" => "Erro ao adicionar produto ao carrinho: " . $e
            ];
        }

        return $this->response->setJSON($response);
    }

    public function update_quantity()
    {
        $action = $this->request->getPost("action");
        $cart_id = $this->request->getPost("cart_id");

        $selectedCart = $this->model->find($cart_id);

        if (!$selectedCart) {
            return redirect()->to("cart");
        }

        $currentCartQuantity = intval($selectedCart->quantity);
        $productStockQuantity = intval($this->productStockModel
            ->where("size", $selectedCart->size)
            ->where("product_id", $selectedCart->product_id)
            ->first()->quantity);

        $newQuantity = ($action == "increase") ? $currentCartQuantity + 1 : $currentCartQuantity - 1;

        if ($productStockQuantity > $newQuantity) {
            if ($newQuantity == 0) {
                $this->model->delete($cart_id);
            } else {
                $this->model->update($cart_id, ["quantity" => $newQuantity]);
            }
        }

        return redirect()->to("cart");
    }

    public function delete($id)
    {
        $this->model->delete($id);
        return redirect()->to("cart");
    }
}
