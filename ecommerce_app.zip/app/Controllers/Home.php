<?php

namespace App\Controllers;

use App\Models\CategoryModel;
use App\Models\ConfigModel;
use App\Models\ProductModel;

class Home extends BaseController
{
    public function index(): string
    {
        $categories = (new CategoryModel)
            ->select("name, image")
            ->orderBy("name")
            ->asObject()
            ->findAll();

        $products = (new ProductModel)
            ->select('product.name, product.price, product_image.url AS image, category.name AS category')
            ->join('product_image', 'product_image.product_id = product.product_id')
            ->join('category', 'category.category_id = product.category_id')
            ->join('product_stock', 'product_stock.product_id = product.product_id')
            ->where('product_stock.quantity >', 0)
            ->groupBy('product.product_id')
            ->asObject()
            ->findAll(5);

        $config = (new ConfigModel)->asObject()->first() ?? null;

        $headerData =  [
            "title" => "Início | e-commerce",
            "config" => $config
        ];

        $categoriesData = [
            "categories" => $categories
        ];

        $homeData = [
            "products"    => $products,
            "categories"  => $categories,
            "banner_url"  => $config->banner_url
        ];

        return view('templates/header', $headerData)
            .  view('templates/categories', $categoriesData)
            .  view('home/home', $homeData)
            .  view('templates/footer', $categoriesData);
    }
}
