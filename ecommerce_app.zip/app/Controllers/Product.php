<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\ProductModel;
use App\Models\ProductImageModel;
use Exception;

class Product extends BaseController
{
    protected $model;
    protected $imageModel;

    public function __construct()
    {
        $this->model = new ProductModel();
        $this->imageModel = new ProductImageModel();
    }

    private function handleImagesUpload($productId)
    {
        $files = $this->request->getFiles('image')['image'] ?? null;

        if ($files) {
            foreach ($files as $file) {
                $newName = $file->getRandomName();
                $file->move('upload', $newName);

                $this->resizeImage('./upload/' . $newName, 720, 720);

                $imageData = [
                    'product_id' => $productId,
                    "url"        => $newName,
                ];

                $this->imageModel->save($imageData);
            }
        }
    }

    private function resizeImage($path, $width, $height)
    {
        $imageService = \Config\Services::image();
        $imageService->withFile($path)->fit($width, $height, 'center')->save();
    }

    public function save()
    {
        $response = [];

        $id = $this->request->getPost("id");
        $data = [
            'category_id'  => $this->request->getPost("category"),
            'name'         => trim($this->request->getPost("name") ?? ""),
            'description'  => $this->request->getPost("description"),
            'price'        => $this->request->getPost("price"),
        ];

        try {
            if ($id) {
                $this->model->update($id, $data);
                $response = [
                    "status"  => "success",
                    "message" => "Produto atualizado com sucesso!"
                ];
            } else {
                if ($this->model->insert($data)) {
                    $id = $this->model->getInsertID();
                    $this->handleImagesUpload($id);
                    $response = [
                        "status"  => "success",
                        "message" => "Produto cadastrado com sucesso!"
                    ];
                }
            }
        } catch (Exception $e) {
            $response = [
                "status"  => "error",
                "message" => "Erro ao salvar produto: " . $e->getMessage()
            ];
        }

        return $this->response->setJSON($response);
    }

    public function get()
    {
        $products = $this->model->findAll();

        foreach ($products as $product) {
            $productImages = $this->imageModel->asObject()->select("url")->where("product_id", $product->product_id)->findAll();
            $product->primaryImage = $productImages[0] ?? null;
            array_shift($productImages);
            $product->secondaryImages = $productImages;
        }

        return $this->response->setJSON($products);
    }

    public function search($name)
    {
        $products = $this->model
            ->select("product.product_id, product.name, product.price, category.name AS category, product_image.url AS image")
            ->like("product.name", $name)
            ->join("product_image", "product_image.product_id = product.product_id")
            ->join("category", "category.category_id = product.category_id")
            ->join('product_stock', 'product_stock.product_id = product.product_id')
            ->where('product_stock.quantity >', 0)
            ->groupBy("product.product_id")
            ->findAll();

        return $this->response->setJSON($products);
    }

    public function delete($id)
    {
        $images = $this->imageModel->where("product_id", $id);

        if ($images->countAllResults()) {
            $imagesToDelete = $images->findAll();
            foreach ($imagesToDelete as $image) {
                if (file_exists("upload/" . $image->url)) {
                    unlink("upload/" . $image->url);
                }
            }

            $this->imageModel->where("product_id", $id)->delete();
        }

        try {
            $this->model->delete($id);

            $response = [
                "status"  => "success",
                "message" => "Produto deletado com sucesso!"
            ];
        } catch (Exception $e) {
            $response = [
                "status"  => "error",
                "message" => "Erro ao deletar produto: " . $e->getMessage()
            ];
        }

        return $this->response->setJSON($response);
    }
}
