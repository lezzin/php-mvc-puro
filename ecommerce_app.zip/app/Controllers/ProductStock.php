<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\ProductStockModel;
use Exception;

class ProductStock extends BaseController
{
    protected $model;

    public function __construct()
    {
        $this->model = new ProductStockModel();
    }

    public function save()
    {
        $response = [];

        $data = [
            'product_id'  => $this->request->getPost("product_id"),
            'size'        => $this->request->getPost("size"),
            'quantity'    => $this->request->getPost("quantity"),
        ];

        try {
            $element = $this->verifyIfSizeExists($data["product_id"], $data['size']);

            if ($element) {
                $id = $element->product_stock_id;
                $data["quantity"] = intval($element->quantity)  + intval($data["quantity"]);
                $this->model->update($id, $data);
                $response = [
                    "status"  => "success",
                    "message" => "Estoque atualizado com sucesso!"
                ];
            } else {
                if ($this->model->insert($data)) {
                    $id = $this->model->getInsertID();
                    $response = [
                        "status"  => "success",
                        "message" => "Estoque cadastrado com sucesso!"
                    ];
                }
            }
        } catch (Exception $e) {
            $response = [
                "status"  => "error",
                "message" => "Erro ao salvar estoque: " . $e->getMessage()
            ];
        }

        return $this->response->setJSON($response);
    }

    public function verifyIfSizeExists($product, $size)
    {
        return $this->model->where("product_id", $product)->where("size", $size)->first();
    }
}
