<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\ConfigModel;
use Exception;

class Config extends BaseController
{
    protected $model;

    public function __construct()
    {
        $this->model = new ConfigModel();
    }

    public function save()
    {
        $currentConfig = $this->model->asObject()->first();
        $currentId = $currentConfig->config_id;
        $currentMessage = $currentConfig->top_message;
        $currentBanner = $currentConfig->banner_url;

        $message = $this->request->getPost("top_message") ? $this->request->getPost("top_message") : $currentMessage;
        $response = [];

        try {
            if ($this->request->getFiles('banner_url')) {
                unlink("../public/upload/{$currentBanner}");

                $banner_url_file = $this->request->getFiles('banner_url')["banner_url"];
                $banner_url = $banner_url_file->getRandomName();
                $banner_url_file->move('upload', $banner_url);
            } else {
                $banner_url = $currentBanner;
            }

            $this->model->save([
                "config_id"   => $currentId,
                "top_message" => $message,
                "banner_url"  => $banner_url,
            ]);

            $response = [
                "status"   => "success",
                "config"   => json_encode($this->model->asObject()->first()),
                "message"  => "Configurações atualizadas com sucesso"
            ];
        } catch (Exception $e) {
            $response = [
                "status"  => "error",
                "message" => "Erro ao atualizar configurações: " . $e->getMessage()
            ];
        }

        return $this->response->setJSON($response);
    }

    public function get()
    {
        return $this->response->setJSON(["config" => $this->model->asObject()->first()]);
    }

    public function delete()
    {
        $column = $this->request->getPost("column");
        $id = $this->request->getPost("id");
        $response = [];

        try {
            $this->model->update($id, [$column => NULL]);

            if($column == "banner_url") {
                $currentImage = $this->model->find($id)->banner_url;
                unlink("../public/upload/{$currentImage}");
            }

            $response = [
                "status"  => "success",
                "message" => "Configurações atualizadas com sucesso"
            ];
        } catch (Exception $e) {
            $response = [
                "status"  => "error",
                "message" => "Erro ao atualizar configurações: " . $e->getMessage()
            ];
        }

        return $this->response->setJSON($response);
    }
}
