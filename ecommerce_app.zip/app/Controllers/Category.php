<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\CategoryModel;
use App\Models\ConfigModel;
use App\Models\ProductImageModel;
use App\Models\ProductModel;
use App\Models\ProductStockModel;
use Exception;

class Category extends BaseController
{
    protected $model;
    protected $productModel;
    protected $productImageModel;
    protected $productStockModel;
    protected $categoryModel;

    public function __construct()
    {
        $this->model = new CategoryModel();
        $this->productModel = new ProductModel();
        $this->productImageModel = new ProductImageModel();
        $this->productStockModel = new ProductStockModel();
    }

    public function category($name)
    {
        $category = $this->model->where("name", get_original_url($name))->asObject()->find()[0] ?? null;

        if (!$category) {
            return redirect()->to('/');
        }

        $products = $this->productModel
            ->select('product.name, product.price, product_image.url AS image, category.name AS category')
            ->join('category', 'category.category_id = product.category_id')
            ->join('product_image', 'product_image.product_id = product.product_id')
            ->join('product_stock', 'product_stock.product_id = product.product_id')
            ->where('product.category_id', $category->category_id)
            ->where('product_stock.quantity >', 0)
            ->groupBy('product.product_id')
            ->paginate(20);

        $productPager = $this->productModel->pager;

        $headerData =  [
            "title"  => "{$category->name} | Ecommerce",
            "config" => (new ConfigModel)->asObject()->first() ?? null,
        ];

        $categoriesData = [
            "categories" => $this->model->select("name")->orderBy("name")->asObject()->findAll()
        ];

        $homeData = [
            "products" => $products,
            "pager" => $productPager,
            "category" => $category
        ];

        $breadcrumdData = [
            "breadcrumbLinks" => [
                ['name' => $category->name, 'active' => true]
            ]
        ];

        return view("templates/header", $headerData)
            .  view('templates/categories', $categoriesData)
            .  view("templates/breadcrumb", $breadcrumdData)
            .  view("category/home", $homeData)
            .  view('templates/footer', $categoriesData);
    }

    public function product($category_name, $product_name)
    {
        $category = $this->model->where("name", get_original_url($category_name))->asObject()->first();

        if (!$category) {
            return redirect()->to('/');
        }

        $product = $this->productModel->where("name", get_original_url($product_name))->first();

        if (!$product) {
            $categoryUrl = "category/" . strtolower($category->name);
            return redirect()->to($categoryUrl);
        }

        $productImages = $this->productImageModel->asObject()->select("url")->where("product_id", $product->product_id)->findAll();

        $product->primaryImage = $productImages[0];
        array_shift($productImages);
        $product->secondaryImages = $productImages;

        $product->stocks = $this->productStockModel->asObject()->where("product_id", $product->product_id)->findAll();

        $headerData =  [
            "title" => "{$product->name} | Ecommerce",
            "config" => (new ConfigModel)->asObject()->first() ?? null,
        ];

        $categoriesData = [
            "categories" => $this->model->select("name")->orderBy("name")->asObject()->findAll()
        ];

        $productData = [
            "product" => $product,
            "category" => $category
        ];

        $breadcrumdData = [
            "breadcrumbLinks" => [
                ['name' => $category->name, 'active' => false, 'url' => "category/{$category->name}"],
                ['name' => $product->name, 'active' => true]
            ]
        ];

        return view("templates/header", $headerData)
            .  view('templates/categories', $categoriesData)
            .  view("templates/breadcrumb", $breadcrumdData)
            .  view("category/product", $productData)
            .  view('templates/footer', $categoriesData);
    }

    public function save()
    {
        $response = [];
        $id = $this->request->getPost("id") ?? null;
        $currentCategory = $this->model->find($id);
        $fileName = null;

        if ($this->request->getFile("image") && $this->request->getFile("image")->isValid()) {
            $image = $this->request->getFile("image");

            $fileName = $image->getRandomName();

            $uploadPath = 'upload/';
            $image->move($uploadPath, $fileName);

            $imageService = \Config\Services::image();

            if (!$imageService->withFile('./' . $uploadPath . $fileName)->fit(480, 480, 'center')->save()) {
                $response = [
                    "status" => "error",
                    "message" => $imageService->error()
                ];
                return $this->response->setJSON($response);
            }

            $imageInfo = getimagesize('./' . $uploadPath . $fileName);
            $width = $imageInfo[0];
            $height = $imageInfo[1];

            if ($width !== $height) {
                unlink('./' . $uploadPath . $fileName);
                $response = [
                    "status" => "error",
                    "message" => "A imagem não é quadrada (proporção 1:1)."
                ];
                return $this->response->setJSON($response);
            }
        }

        try {
            $this->model->save([
                'category_id' => $id,
                'name'        => trim($this->request->getPost("name") ?? $currentCategory->name),
                'image'       => $fileName ?? $currentCategory->image,
            ]);

            $response = [
                "status" => "success",
                "message" => "Categoria " . ($id ? "atualizada" : "salva") . " com sucesso!"
            ];
        } catch (Exception $e) {
            $response = [
                "status" => "error",
                "message" => "Erro ao " . ($id ? "atualizar" : "salvar") . " categoria: " . $e->getMessage()
            ];
        }

        return $this->response->setJSON($response);
    }

    public function get()
    {
        $categories = $this->model->asObject()->findAll();
        return $this->response->setJSON($categories);
    }

    public function delete($id)
    {
        $response = [];

        $imageToDelete = $this->model->select("image")->where("category_id", $id)->first()->image;
        if ($imageToDelete and file_exists("upload/" . $imageToDelete)) {
            unlink("upload/" . $imageToDelete);
        }

        try {
            $this->model->delete($id);
            $response = [
                "status" => "success",
                "message" => "Categoria deletada com sucesso!"
            ];
        } catch (Exception $e) {
            $response = [
                "status" => "success",
                "message" => "Erro ao deletar categoria: " . $e->getMessage()
            ];
        }

        return $this->response->setJSON($response);
    }
}
