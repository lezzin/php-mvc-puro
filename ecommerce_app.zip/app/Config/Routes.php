<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');

$routes->group("user", function ($routes) {
    $routes->match(['get', 'post'], 'login', 'User::login', ["as" => "login"]);
    $routes->match(['get', 'post'], 'register', 'User::register');
    $routes->get('logout', 'User::logout');
});

$routes->group('admin', ['filter' => 'admin'], function ($routes) {
    $routes->get('', 'Admin::index');
    $routes->get('category', 'Admin::category');
    $routes->get('product', 'Admin::product');
    $routes->get('customs', 'Admin::customs');
});

$routes->group('config', ['filter' => 'admin'], function ($routes) {
    $routes->post('actions/save', 'Config::save');
    $routes->get('actions/get', 'Config::get');
    $routes->post('actions/delete', 'Config::delete');
});

$routes->group('category', function ($routes) {
    $routes->post('actions/save', 'Category::save', ['filter' => 'admin'],);
    $routes->get('actions/get', 'Category::get');
    $routes->get('(:segment)', 'Category::category/$1');
    $routes->get('(:segment)/products/(:segment)', 'Category::product/$1/$2');
    $routes->delete('actions/delete/(:num)', 'Category::delete/$1', ['filter' => 'admin']);
});

$routes->group('product', function ($routes) {
    $routes->post('actions/save', 'Product::save', ['filter' => 'admin'],);
    $routes->get('actions/get', 'Product::get');
    $routes->get('actions/search/(:segment)', 'Product::search/$1');
    $routes->delete('actions/delete/(:num)', 'Product::delete/$1', ['filter' => 'admin'],);
});

$routes->group('stock',  ['filter' => 'admin'], function ($routes) {
    $routes->post('actions/save', 'ProductStock::save');
});

$routes->group('cart', ['filter' => 'customer'], function ($routes) {
    $routes->get('/', 'Cart::index');
    $routes->post('actions/save', 'Cart::save');
    $routes->get('actions/get', 'Cart::get');
    $routes->post('actions/update_quantity', 'Cart::update_quantity');
    $routes->get('actions/delete/(:num)', 'Cart::delete/$1');
});
